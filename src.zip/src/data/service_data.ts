

interface DataType {
  title: string;
  description: string;
}


const service_data: DataType[] = [
	{
		title: "Digital Marketing",
		description: `Welcome to our digital agency! We specialize in helping businesses like yours succeed`,
	},
	{
		title: "Digital Marketing",
		description: `Welcome to our digital agency! We specialize in helping businesses like yours succeed`,
	},
	{
		title: "Digital Marketing",
		description: `Welcome to our digital agency! We specialize in helping businesses like yours succeed`,
	},
	{
		title: "Digital Marketing",
		description: `Welcome to our digital agency! We specialize in helping businesses like yours succeed`,
	},
	{
		title: "Digital Marketing",
		description: `Welcome to our digital agency! We specialize in helping businesses like yours succeed`,
	},
	{
		title: "Digital Marketing",
		description: `Welcome to our digital agency! We specialize in helping businesses like yours succeed`,
	},
];

export default service_data;
