
//  Gsap Plugin import here 
 
export { default as Gsap } from "../../public/assets/plugins/gsap.js";
export { default as SplitText } from "../../public/assets/plugins/gsap-split-text.js"; 
export { default as ScrollTrigger } from "../../public/assets/plugins/gsap-scroll-trigger.js";
export { default as ScrollSmoother } from "../../public/assets/plugins/gsap-scroll-smoother.js";
export { default as ScrollToPlugin } from "../../public/assets/plugins/gsap-scroll-to-plugin.js";





